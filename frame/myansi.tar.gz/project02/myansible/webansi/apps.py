from django.apps import AppConfig


class WebansiConfig(AppConfig):
    name = 'webansi'
