from django.conf.urls import url
from webansi import views

urlpatterns = [
    url(r'^$', views.mainpage, name='mainpage'),
    url(r'^addhosts/$', views.addhosts, name='addhosts'),
    url(r'^addmodules/$', views.addmodules, name='addmodules'),
    url(r'^tasks/$', views.tasks, name='tasks'),
    url(r'^rmarg/(?P<arg_id>\d+)/$', views.rmarg, name='rmarg'),
    url(r'^rmmod/(?P<mod_id>\d+)/$', views.rmmod, name='rmmod'),
    url(r'^rmhost/(?P<host_id>\d+)/$', views.rmhost, name='rmhost'),
    url(r'^rmgroup/(?P<group_id>\d+)/$', views.rmgroup, name='rmgroup'),
]