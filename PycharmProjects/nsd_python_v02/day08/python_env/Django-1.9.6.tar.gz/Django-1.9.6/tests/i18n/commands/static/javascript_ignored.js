gettext('Content from STATIC_ROOT should not be included.')
