#!/usr/bin/env python3
#__*__coding: utf8__*__
name = input('请输入用户名：')
if name == 'tom':
    print('登陆成功')
else:
    print('登录失败')