__author__ = 'root'

a = 5
b= 3
c = a+b
print(c)