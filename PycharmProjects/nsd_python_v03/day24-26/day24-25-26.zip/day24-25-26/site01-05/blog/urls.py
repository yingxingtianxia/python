from django.conf.urls import url
from .views import index,test


urlpatterns = [
    url(r'^$',index),
    url(r'^t',test),
]