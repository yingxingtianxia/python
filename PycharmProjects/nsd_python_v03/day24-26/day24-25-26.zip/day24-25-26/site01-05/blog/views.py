from django.shortcuts import render,HttpResponse
from .models import Post

# Create your views here.

def index(request):
    page = request.GET.get('page')

    lstPost = Post.objects.all()

    return render(request,"index.html",{'posts': lstPost})

def test(request):
    a = [1,2,3,4,5]
    b = "hello"

    return render(request,"t.html",{'a':a,'b':b})