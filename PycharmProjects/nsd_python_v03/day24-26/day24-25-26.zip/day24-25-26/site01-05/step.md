# 添加应用

	cd /var/ftp/py1712/site01
	python3 manage.py startapp blog

# 安装应用
site01/settings.py
## 40行位置
INSTALLED_APPS 添加

    'blog'

# URL 配置

## 修改 site01/urls.py
### 16 行
	 from django.conf.urls import url,include
### 20 行 ，
	url(r'^blog/', include("blog.urls"))

## 创建blog/urls.py 文件

	from django.conf.urls import url
	from .views import index


	urlpatterns = [
   	 	url(r'^$',index)
	]
## 定义view/  blog/views.py

    from django.shortcuts import render,HttpResponse

    def index(request):
        return HttpResponse("hello")