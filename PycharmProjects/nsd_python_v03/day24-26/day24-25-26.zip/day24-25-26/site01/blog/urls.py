from django.conf.urls import url
from .views import *

urlpatterns = [
    url(r'^index$',index),
    url(r'^$',index),
    url(r'^r$',renderIndex),
    url(r'^list$',showList),
    url(r'^add$',add),
    url(r'^edit/(?P<id>\d+)$',edit),
    url(r'^del$',delPost),
    url(r'^ajaxdel$',ajaxDel)
]
