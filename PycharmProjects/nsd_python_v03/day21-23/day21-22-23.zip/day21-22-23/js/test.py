__author__ = 'root'

print("hello")


