# urllib

1、 url规则
2、模拟浏览器   www.goubanjia.com

	User-Agent
	Referer

3 Post
data={'username':'1','password':'1'}
172.40.50.127:8888/login


Cookie:
csrftoken=4EGTEFQvW1f00JVTa4FsgI1vWDYg4xnQ; sessionid=ni2fvu8zxtzt5sqkwaksporumcu90224; uid=2|1:0|10:1527942835|3:uid|4:YWJj|d9063b2a749b9b9eb3b47e31b15b521fc95b72f300bd444f5b66d98c746d2ba9


xss





waf: web application firewall


http://2018.ip138.com/ic.asp

# requests 安装

pip3 install requests

## params

/edit/2

## data




<tr>
    <td height="30"><p align="left">
    <a href="javascript:commitForECMA(callbackC,'content.jsp?tableId=120&amp;tableName=TABLE120&amp;tableView=食品生产许可获证企业(SC)&amp;Id=178',null)">91.绍兴金宇酒业有限公司 (SC10333062100084)</a></p></td></tr>
<tr>
	<td height="1" background="images/data01_04.gif"></td></tr>

doc('#p2')

<a ></a>


#content > table:nth-child(2)

#content > table:nth-child(2) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(1) > p:nth-child(1)







<a href='' >

pq(a).attr('href')




div.quote

 span:nth-child(2) > small:nth-child(1)

 span:nth-child(2) > a:nth-child(2)


#  pip3 install pyspider

yum install libcurl-devel -y




30-9=


拨号vps










 
