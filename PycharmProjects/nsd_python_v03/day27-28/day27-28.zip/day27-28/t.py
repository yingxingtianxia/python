a = "%s%s%s"%(1,1,1)
print(a)
a = "{0}{1}{0}".format(1,2)
print(a)